import WeatherLocApp from "./WeatherLocApp";
import "./WeatherLocApp.css"

function App() {
  return (
    <div className="main-container">
      <WeatherLocApp />
    </div>
  );
}

export default App;
